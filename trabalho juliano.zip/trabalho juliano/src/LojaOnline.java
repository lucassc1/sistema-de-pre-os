public class LojaOnline {
    public static void main(String[] args) {
        // Criando produtos
        Produto produto1 = new Produto("Produto A", 100.00);
        Produto produto2 = new Produto("Produto B", 200.00);

        // Criando o carrinho de compras
        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
        carrinho.adicionarProduto(produto1);
        carrinho.adicionarProduto(produto2);

        // Estratégia para cliente novo
        carrinho.setDescontoStrategy(new DescontoClienteNovo());
        System.out.println("Total para cliente novo: " + carrinho.calcularTotal());

        // Estratégia para cliente regular
        carrinho.setDescontoStrategy(new DescontoClienteRegular());
        System.out.println("Total para cliente regular: " + carrinho.calcularTotal());

        // Estratégia para cliente VIP
        carrinho.setDescontoStrategy(new DescontoClienteVIP());
        System.out.println("Total para cliente VIP: " + carrinho.calcularTotal());
    }
}
